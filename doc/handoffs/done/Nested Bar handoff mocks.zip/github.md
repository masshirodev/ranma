repo: masshirodev/ranma
branch: main

## Last sync
date: 2026-09-29T18:59:27Z

### Updated in this project
- Nested-bar design handoff (new), built on src/bar.rs and src/render.rs
- Cell mock export: NESTED_BAR_MOCK.txt

## Screen map
| Screen | Repo files |
|---|---|
| Nested Bar.dc.html | src/bar.rs, src/render.rs, src/app/mod.rs (bar modules), assets/themes/default.toml, doc/handoffs/WHICH_KEY_MOCK.txt |
