// Cell-accurate model of ranma's bar with the nested-workspace design.
// fit/join/truncate are ports of src/bar.rs; wsPieces is the proposed spelling.
(function () {
  const THEMES = {
    default: {
      term_bg: '#1e1e2e', bar_bg: '#1e1e2e', bar_fg: '#cdd6f4', bar_dim: '#6c7086', bar_accent: '#89b4fa',
      mode_fg: '#1e1e2e', mode_bg: '#f38ba8', ws_active_fg: '#1e1e2e', ws_active_bg: '#89b4fa',
      ws_occupied: '#cdd6f4', ws_empty: '#6c7086', ws_urgent: '#f38ba8',
      border_active: '#89b4fa', border_inactive: '#45475a',
      accents: { l1: '#a6e3a1', l2: '#f9e2af', other: '#cba6f7' },
    },
    matugen: {
      term_bg: '#17130d', bar_bg: '#17130d', bar_fg: '#ece0d2', bar_dim: '#8c8174', bar_accent: '#e9c07d',
      mode_fg: '#2b1c0c', mode_bg: '#f2b8a4', ws_active_fg: '#2b1c0c', ws_active_bg: '#e9c07d',
      ws_occupied: '#ece0d2', ws_empty: '#8c8174', ws_urgent: '#ffb4ab',
      border_active: '#e9c07d', border_inactive: '#4e463b',
      accents: { l1: '#b4d18c', l2: '#9ccbe6', other: '#e4b4dc' },
    },
  };
  const SEP = '  ';
  const TITLE = '✳Features to yank from tuios';
  const W = (s) => [...s].length;
  const width = (ps) => ps.reduce((a, p) => a + W(p.t), 0);

  function join(segs, sep) {
    const out = [];
    for (const s of segs.filter((s) => width(s) > 0)) {
      if (out.length && sep) out.push({ t: sep, r: 'dim' });
      out.push(...s);
    }
    return out;
  }
  function truncate(ps, max) {
    if (width(ps) <= max) return ps;
    if (max === 0) return [];
    const out = [];
    let used = 0;
    for (const p of ps) {
      const w = W(p.t);
      if (used + w < max) { used += w; out.push(p); continue; }
      let t = '';
      for (const c of p.t) { if (used + 2 > max) break; used += 1; t += c; }
      out.push({ ...p, t: t + '…' });
      break;
    }
    return out;
  }
  // bar::fit, plus one change: a centre that would be cut below `floor` cells is left out.
  function fit(left, center, right, sep, cols, floor) {
    right = truncate(join(right, sep), cols);
    const rw = width(right);
    left = truncate(join(left, sep), Math.max(0, cols - (rw + (rw > 0 ? 1 : 0))));
    const lw = width(left);
    const out = [];
    let x = 0;
    for (const p of left) { out.push([x, p]); x += W(p.t); }
    const gs = lw + (lw > 0 ? 1 : 0);
    const ge = Math.max(0, cols - (rw + (rw > 0 ? 1 : 0)));
    const room = Math.max(0, ge - gs);
    let c = join(center, sep);
    if (floor && width(c) > room && room < floor) c = [];
    c = truncate(c, room);
    const cw = width(c);
    if (cw > 0) {
      const ideal = Math.floor(Math.max(0, cols - cw) / 2);
      let cx = Math.min(Math.max(ideal, gs), Math.max(ge - cw, gs));
      for (const p of c) { out.push([cx, p]); cx += W(p.t); }
    }
    let rx = cols - rw;
    for (const p of right) { out.push([rx, p]); rx += W(p.t); }
    return out;
  }

  const anyUrgent = (set) => set.ws.some((w) => w.urgent || (w.nest && !w.nest.legacy && anyUrgent(w.nest)));

  // o: { expandAll, collapse, dropFrom (levels >= this lose non-path names), dropCur }
  function wsPieces(set, level, onPath, o) {
    const out = [];
    const pad = level === 0;
    const push = (t, r, acc) => out.push({ t, r, acc });
    const dropFrom = o.dropFrom ?? Infinity;
    set.ws.forEach((w, i) => {
      if (!pad && i > 0) push(' ', 'normal');
      const cur = w.n === set.current;
      const path = onPath && cur;
      const reported = w.nest && !w.nest.legacy;
      const expand = reported && (path || (o.expandAll && !o.collapse));
      const keepName = path ? !o.dropCur : level < dropFrom;
      if (expand) {
        const sess = w.nest.sessions > 1 ? ':' + w.nest.session : '';
        if (pad) push(` ${w.n}${sess} `, cur ? 'wsActive' : 'wsOccupied', set.accent);
        else { push(`${w.n}${sess}`, path ? 'holder' : 'wsOccupied'); push(' ', 'normal'); }
        push('[', 'bracket');
        out.push(...wsPieces(w.nest, level + 1, path, o));
        push(']', 'bracket');
        if (pad) push(' ', 'normal');
        return;
      }
      const label = keepName && w.name ? `${w.n}:${w.name}` : `${w.n}`;
      let r;
      if (cur && level === 0) r = 'wsActive';
      else if (path) r = 'innerCur';
      else if (cur) r = 'holder';
      else if (w.urgent || (reported && anyUrgent(w.nest))) r = 'wsUrgent';
      else r = w.occ ? 'wsOccupied' : 'wsEmpty';
      push(pad ? ` ${label} ` : label, r, set.accent);
    });
    if (set.scratch) { if (!pad) push(' ', 'normal'); push(pad ? ' S ' : 'S', 'wsOccupied'); }
    return out;
  }

  const STEPS = [
    { label: 'Everything, the title cut to what is left', o: {} },
    { label: 'Other expanded groups collapse to their holder', o: { collapse: true }, expandAllOnly: true },
    { label: 'Second-level names go, numbers stay', o: { dropFrom: 2 } },
    { label: 'Inner names go, numbers stay', o: { dropFrom: 1 } },
    { label: 'Outer names go, numbers stay', o: { dropFrom: 0 } },
    { label: 'Names on your path go', o: { dropCur: true } },
  ];

  function scenario({ levels = 1, innerCurrent = 3, legacy = false, accents, sessions = 1 }) {
    const innermost = { sessions: 1, session: 'lab', current: 2, accent: accents.l2,
      ws: [{ n: 1, name: 'htop', occ: 1 }, { n: 2, name: 'logs', occ: 1 }] };
    const inner = legacy ? { legacy: true } : {
      sessions, session: 'work', current: innerCurrent, accent: accents.l1, scratch: true,
      ws: [{ n: 1, name: 'kumiko', occ: 1 }, { n: 2, name: 'notebooks', occ: 1 }, { n: 3, name: 'ranma', occ: 1 },
        { n: 4, name: 'ranobe', occ: 1 }, { n: 5, name: 'zsh', occ: 1, nest: levels > 1 ? innermost : null }],
    };
    const ai = { sessions: 1, session: 'gpu', current: 1, accent: accents.other,
      ws: [{ n: 1, name: 'claude', occ: 1 }, { n: 2, name: 'zsh', occ: 1 }] };
    return { mode: true, accent: null, current: 2,
      ws: [{ n: 1, name: 'zsh', occ: 1 }, { n: 2, name: 'ssh', occ: 1, nest: inner }, { n: 3, name: 'ai', occ: 1, nest: ai }] };
  }

  function roleStyle(r, acc, T) {
    switch (r) {
      case 'dim': case 'bracket': return [T.bar_dim, T.bar_bg, 0];
      case 'accent': return [T.bar_accent, T.bar_bg, 0];
      case 'mode': return [T.mode_fg, T.mode_bg, 1];
      case 'wsActive': return [T.ws_active_fg, acc || T.ws_active_bg, 1];
      case 'wsOccupied': return [T.ws_occupied, T.bar_bg, 0];
      case 'wsEmpty': return [T.ws_empty, T.bar_bg, 0];
      case 'wsUrgent': return [T.ws_urgent, T.bar_bg, 1];
      case 'holder': return [T.ws_occupied, T.bar_bg, 1];
      case 'innerCur': return [acc || T.ws_active_bg, T.bar_bg, 1];
      default: return [T.bar_fg, T.bar_bg, 0];
    }
  }
  const blank = (T, bg) => ({ ch: ' ', fg: T.bar_fg, bg: bg || T.bar_bg, b: 0 });
  function cellsOf(placed, cols, T) {
    const cells = Array.from({ length: cols }, () => blank(T));
    for (const [x, p] of placed) {
      const [fg, bg, b] = roleStyle(p.r, p.acc, T);
      let i = x;
      for (const ch of p.t) { if (i < cols) cells[i] = { ch, fg, bg, b }; i++; }
    }
    return cells;
  }
  const RIGHT = [[{ t: 'Tue 29 Sep', r: 'normal' }], [{ t: '14:42', r: 'normal' }]];

  function bar(scn, cols, T, { expandAll = false, force = null } = {}) {
    const rw = width(join(RIGHT, SEP));
    const steps = STEPS.filter((s) => expandAll || !s.expandAllOnly);
    const o = { expandAll };
    let k, left;
    for (k = 0; k < steps.length; k++) {
      Object.assign(o, steps[k].o);
      left = [scn.mode ? [{ t: ' ⧉ ', r: 'dim' }] : [], wsPieces(scn, 0, true, o)];
      const fits = width(join(left, SEP)) + rw + 1 <= cols;
      if (force != null ? k === force : fits) break;
    }
    if (k === steps.length) k--;
    const lw = width(join(left, SEP));
    const placed = fit(left, [[{ t: TITLE, r: 'normal' }]], RIGHT, SEP, cols, 12);
    return { cells: cellsOf(placed, cols, T), k, step: steps[k], lw, need: lw + rw + 1, fits: lw + rw + 1 <= cols, steps };
  }

  // Screens
  const grid = (cols, rows, T) => Array.from({ length: rows }, () => Array.from({ length: cols }, () => blank(T, T.term_bg)));
  function put(g, x, y, s, fg, b = 0) {
    let i = x;
    for (const ch of s) { if (g[y] && i < g[y].length) g[y][i] = { ...g[y][i], ch, fg, b }; i++; }
  }
  function box(g, x, y, w, h, title, col, T) {
    put(g, x, y, '╭' + '─'.repeat(w - 2) + '╮', col);
    for (let r = y + 1; r < y + h - 1; r++) { put(g, x, r, '│', col); put(g, x + w - 1, r, '│', col); }
    put(g, x, y + h - 1, '╰' + '─'.repeat(w - 2) + '╯', col);
    if (title) put(g, x + 1, y, ' ' + [...title].slice(0, w - 4).join('') + ' ', T.bar_fg);
  }
  function screenAlone(T, accents) {
    const g = grid(80, 14, T);
    box(g, 0, 0, 48, 13, TITLE, T.border_active, T);
    box(g, 48, 0, 32, 13, 'zsh', T.border_inactive, T);
    put(g, 2, 1, '~/src/ranma $ claude', T.bar_dim);
    put(g, 50, 1, '~ $', T.bar_dim);
    g[13] = bar(scenario({ accents }), 80, T).cells;
    return g;
  }
  function screenBeside(T, accents) {
    const g = grid(80, 14, T);
    box(g, 0, 0, 26, 13, 'zsh', T.border_inactive, T);
    put(g, 2, 1, '~ $', T.bar_dim);
    box(g, 26, 0, 54, 13, '', T.border_active, T);
    box(g, 27, 1, 30, 11, TITLE, T.border_active, T);
    box(g, 57, 1, 22, 11, 'zsh', T.border_inactive, T);
    put(g, 29, 2, '~/src/ranma $ claude', T.bar_dim);
    put(g, 59, 2, '~ $', T.bar_dim);
    g[13] = bar(scenario({ accents }), 80, T).cells;
    return g;
  }
  function screenToday(T, accents) {
    const g = grid(80, 14, T);
    box(g, 0, 0, 80, 13, TITLE, T.border_active, T);
    box(g, 1, 1, 39, 10, 'ranma', T.border_inactive, T);
    box(g, 40, 1, 39, 10, TITLE, T.border_active, T);
    put(g, 3, 2, '~/src/ranma $', T.bar_dim);
    put(g, 42, 2, '~/src/ranma $ claude', T.bar_dim);
    const inner = scenario({ accents }).ws[1].nest;
    const innerSet = { ...inner, ws: inner.ws.map((w) => ({ ...w, nest: null })) };
    const ip = fit([wsPieces(innerSet, 0, true, {})], [[{ t: TITLE, r: 'normal' }]], RIGHT, SEP, 78, 0);
    const ic = cellsOf(ip, 78, T);
    ic.forEach((c, i) => { g[11][i + 1] = c; });
    const outer = scenario({ legacy: true, accents });
    const op = fit([[{ t: ' ⧉ ', r: 'dim' }], wsPieces(outer, 0, true, {})], [[{ t: TITLE, r: 'normal' }]], RIGHT, SEP, 80, 0);
    g[13] = cellsOf(op, 80, T);
    return g;
  }

  const ODD = /[^\x20-\x7e…]/;
  function spans(cells) {
    const out = [];
    let cur = null;
    for (const c of cells) {
      const odd = ODD.test(c.ch);
      const key = c.fg + c.bg + c.b;
      if (!odd && cur && !cur.odd && cur.key === key) { cur.t += c.ch; continue; }
      cur = { t: c.ch, key, odd, css: { color: c.fg, background: c.bg, fontWeight: c.b ? 700 : 400,
        ...(odd ? { display: 'inline-block', width: '1ch', textAlign: 'center', height: '17px', lineHeight: '17px', verticalAlign: 'top', ...(/[\u2500-\u257f]/.test(c.ch) ? { textAlign: 'left', transform: 'scaleX(1.25)', transformOrigin: 'left' } : {}) } : {}) } };
      out.push(cur);
    }
    return out.map(({ t, css }) => ({ t, css }));
  }
  const text = (rows) => rows.map((r) => r.map((c) => c.ch).join('').replace(/\s+$/, '')).join('\n');

  const api = { THEMES, STEPS, SEP, TITLE, scenario, bar, wsPieces, roleStyle, cellsOf, fit, spans, text, screenAlone, screenBeside, screenToday };
  if (typeof window !== 'undefined') window.NestedBar = api;
  if (typeof globalThis !== 'undefined') globalThis.NestedBar = api;
})();
