repo: masshirodev/ranma
branch: main

## Last sync
date: 2026-09-29T18:10:00Z

### Updated in this project
- Which-key hint design (card c64): mocks at 80×24, 120×35, 200×50 and nested 40×15
- Colour roles, overflow rules, key layout and brief corrections

## Screen map
| Screen | Repo files |
| --- | --- |
| Which-key hint.dc.html | doc/briefs/WHICH_KEY.md, assets/init.lua, assets/themes/default.toml, src/render.rs, src/bar.rs, src/theme.rs, src/app/mod.rs, src/app/switch.rs |
