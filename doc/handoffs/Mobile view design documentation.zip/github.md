repo: masshirodev/ranma
branch: main

## Last sync
date: 2026-09-30T01:09:31Z

### Updated in this project
- Mobile view design for doc/briefs/MOBILE_VIEW.md
- Cell-for-cell mocks: phone, sheets, landscape, tablet, desktop
- New colour roles with defaults from assets/themes/default.toml

## Screen map
| Screen | Repo files |
|---|---|
| Mobile View.dc.html (bar, borders, tabs) | src/render.rs, src/bar.rs, src/app/mod.rs |
| Mobile View.dc.html (sheets, pane menu) | src/app/switch.rs, src/picker.rs |
| Mobile View.dc.html (colours) | src/theme.rs, assets/themes/default.toml |
| Mobile View.dc.html (prior art) | doc/handoffs/done/NESTED_BAR_MOCK.txt, doc/handoffs/done/WHICH_KEY_MOCK.txt |
| Term.dc.html (cell renderer) | src/render.rs |
